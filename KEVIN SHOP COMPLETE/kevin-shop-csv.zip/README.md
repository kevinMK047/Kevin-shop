# Kevin's Online Shop

This is a simple online shop website powered by CSV.

- Edit **products.csv** to add or change products.
- Upload product images into the **images/** folder.
- Deploy with GitHub Pages.
