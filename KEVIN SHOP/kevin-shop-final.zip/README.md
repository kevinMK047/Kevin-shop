# Kevin's Online Shop

This is a simple static website for Kevin's Online Shop. Upload the files to a GitHub repository and enable GitHub Pages (main branch / root) to publish.

Files:
- index.html
- about.html
- contact.html
- images/logo.png
- images/banner.png
